const wishForm = document.getElementById("wishForm");
const wishInput = document.getElementById("wishInput");
const wishList = document.getElementById("wishList");

function loadWishes() {
  fetch('api.php', {
    method: 'GET',
  })
  .then(response => response.json())
  .then(data => {
    renderWishes(data);
  })
  .catch(error => console.error('Error al cargar los deseos:', error));
}

function addWish(descripcion) {
  fetch('api.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ descripcion: descripcion }),
  })
  .then(response => response.json())
  .then(data => {
    if (data.message) {
      loadWishes(); 
    } else {
      console.error('Error al agregar el deseo:', data.error);
    }
  })
  .catch(error => console.error('Error al agregar el deseo:', error));
}

function deleteWish(id) {
  fetch('api.php', {
    method: 'DELETE',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ id: id }),
  })
  .then(response => response.json())
  .then(data => {
    if (data.message) {
      loadWishes(); 
    } else {
      console.error('Error al eliminar el deseo:', data.error);
    }
  })
  .catch(error => console.error('Error al eliminar el deseo:', error));
}

function renderWishes(wishes) {
  wishList.innerHTML = "";

  if (wishes.length === 0) {
    const empty = document.createElement("li");
    empty.className = "list-group-item text-muted text-center";
    empty.textContent = "No hay deseos agregados.";
    wishList.appendChild(empty);
    return;
  }

  wishes.forEach((wish) => {
    const li = document.createElement("li");
    li.className = "list-group-item d-flex justify-content-between align-items-start flex-column flex-sm-row";
    li.innerHTML = `
      <div>
        <strong>${wish.descripcion}</strong><br>
        <small class="text-muted">Agregado el: ${new Date(wish.fecha).toLocaleString()}</small>
      </div>
      <button class="btn btn-sm btn-outline-danger mt-2 mt-sm-0" onclick="deleteWish(${wish.id})">Eliminar</button>
    `;
    wishList.appendChild(li);
  });
}

wishForm.addEventListener("submit", function (e) {
  e.preventDefault();

  const descripcion = wishInput.value.trim();
  if (descripcion !== "") {
    addWish(descripcion);
    wishInput.value = "";
  }
});

loadWishes();
